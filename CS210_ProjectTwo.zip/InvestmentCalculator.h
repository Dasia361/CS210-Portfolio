#ifndef INVESTMENT_CALCULATOR_H_

#define INVESTMENT_CALCULATOR_H_



class InvestmentCalculator {

public:

    void getUserInput();

    void displayInputScreen() const;

    void displayReports() const;



private:

    double initialInvestment;

    double monthlyDeposit;

    double annualInterest;

    int numberOfYears;



    void printReportWithoutDeposit() const;

    void printReportWithDeposit() const;

};



#endif
