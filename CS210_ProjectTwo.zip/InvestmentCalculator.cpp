#include "InvestmentCalculator.h"
#include <iostream>
#include <iomanip>

using namespace std;

void InvestmentCalculator::getUserInput() {
    cout << "Initial Investment Amount: ";
    cin >> initialInvestment;

    cout << "Monthly Deposit: ";
    cin >> monthlyDeposit;

    cout << "Annual Interest (%): ";
    cin >> annualInterest;

    cout << "Number of Years: ";
    cin >> numberOfYears;
}

void InvestmentCalculator::displayInputScreen() const {
    cout << "\nPress Enter to continue...";
    cin.ignore();
    cin.get();
}

void InvestmentCalculator::displayReports() const {
    printReportWithoutDeposit();
    printReportWithDeposit();
}

void InvestmentCalculator::printReportWithoutDeposit() const {
    double balance = initialInvestment;

    cout << "\nBalance Without Monthly Deposits\n";

    for (int year = 1; year <= numberOfYears; year++) {
        double interest = 0;

        for (int month = 0; month < 12; month++) {
            double monthlyInterest = balance * ((annualInterest / 100) / 12);
            interest += monthlyInterest;
            balance += monthlyInterest;
        }

        cout << year << "  $" << fixed << setprecision(2)
            << balance << "  $" << interest << endl;
    }
}

void InvestmentCalculator::printReportWithDeposit() const {
    double balance = initialInvestment;

    cout << "\nBalance With Monthly Deposits\n";

    for (int year = 1; year <= numberOfYears; year++) {
        double interest = 0;

        for (int month = 0; month < 12; month++) {
            balance += monthlyDeposit;
            double monthlyInterest = balance * ((annualInterest / 100) / 12);
            interest += monthlyInterest;
            balance += monthlyInterest;
        }

        cout << year << "  $" << fixed << setprecision(2)
            << balance << "  $" << interest << endl;
    }
}