#include <iostream>
#include <cctype>
#include "InvestmentCalculator.h"

using namespace std;

int main() {
    char runAgain = 'y';

    while (tolower(runAgain) == 'y') {
        InvestmentCalculator calculator;

        calculator.getUserInput();
        calculator.displayInputScreen();
        calculator.displayReports();

        cout << endl;
        cout << "Would you like to enter another scenario? (y/n): ";
        cin >> runAgain;
        cin.ignore(1000, '\n');
    }

    cout << "Thank you for using the Airgead Banking App." << endl;
    return 0;
}